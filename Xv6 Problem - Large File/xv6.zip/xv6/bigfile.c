#include "user.h"
#include "fcntl.h"
#include "fs.h"

#define uint unsigned int
int main(int argc, char const *argv[])
{
	int fd;
	fd = open("test.txt",O_CREATE | O_WRONLY);
	if(fd == -1) {
		printf(2,"File not created successfully");
		exit();
	}

	char block[BSIZE];
	int numberOfBlocks=0;
	memset(block,numberOfBlocks,sizeof(block));
	while(write(fd,block,sizeof(block)) > 0){
		numberOfBlocks++;
		if(numberOfBlocks%1000==1)printf(2,". ");
		memset(block,numberOfBlocks % 32,sizeof(block));
	}
	printf(2,"\n");
	printf(1,"Number of blocks written are: %d\n", numberOfBlocks);
	printf(2,"done, ok \n");
	close(fd);
	numberOfBlocks = 0;
	
	exit();
}
